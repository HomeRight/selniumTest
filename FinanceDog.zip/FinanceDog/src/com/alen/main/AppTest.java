package com.alen.main;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.alen.util.DateFormatUtil;
import com.alen.util.PropertiesUtil;

public class AppTest {

	private static Logger logger = LogManager.getLogger(AppTest.class);

	// selenium �D����
	private static WebDriver driver;

	// �ƹ��ʧ@����
	private static Actions action;

	// Javascript ���檫��
	static JavascriptExecutor js;

	private static final String OVERDUE_DATE_FORMAT = "yyyy/MM/dd";

	public static void main(String[] arg) {

		// Ū���]�w��
		try {
			PropertiesUtil.init("application.properties");
		} catch (Exception e) {
			logger.error("Ū���~���]�w�� jobTemporaryLease.properties ����", e);
			return;
		}

		try {
			String reportContent = runselenium();
//
			System.out.println("reportContent" + reportContent);

			send(reportContent, PropertiesUtil.getValue("mail.addr.to"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void send(String reportContent, String to) {

		try {
			Properties props = new Properties();
			props.put("mail.smtp.host", "smtp-mail.outlook.com");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.ssl.trust", "smtp-mail.outlook.com");
			props.put("mail.smtp.starttls.enable", "true");
//			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.connectiontimeout", "10000");

			final String EmailUser = PropertiesUtil.getValue("email.account");
			final String EmailPassword = PropertiesUtil.getValue("email.password");

			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(EmailUser, EmailPassword);
				}
			});

			session.setDebug(true);
			InternetAddress fromAddress = new InternetAddress("alensu@fareastone.com.tw", "finance dog");

			Date newdate = new Date();
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(newdate);
			String msgSubject = DateFormatUtil.format(calendar.getTime(), OVERDUE_DATE_FORMAT) + "�z����";

			MimeMessage msg = new MimeMessage(session);
			msg.setFrom(fromAddress);
			msg.addRecipients(Message.RecipientType.TO, to);
			msg.setSubject(msgSubject);
//			msg.setText(reportContent);

			MimeBodyPart textPart = new MimeBodyPart();
			Multipart email = new MimeMultipart();

			textPart.setContent(reportContent.toString(), "text/html; charset=utf-8");
			email.addBodyPart(textPart);
			msg.setContent(email);

			Transport transport = session.getTransport("smtp");
			transport.connect();
			transport.sendMessage(msg, msg.getAllRecipients());

		} catch (

		MessagingException e) {
			System.out.println(e.getMessage() + e.getStackTrace());
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		}
	}

	private static String runselenium() throws Exception {

		System.setProperty("webdriver.chrome.driver", "D://chromedriver.exe");
		driver = new ChromeDriver();
		js = (JavascriptExecutor) driver;
		action = new Actions(driver);

		StringBuilder content = new StringBuilder();

		driver.get("https://statementdog.com/users/sign_in");
		driver.findElement(By.id("user_email")).sendKeys("changsu20200812@outlook.com");
		driver.findElement(By.id("user_password")).sendKeys("cs830529");
		driver.findElement(By.cssSelector(".submit-btn")).click();
		TimeUnit.SECONDS.sleep(2);

		driver.findElement(By.cssSelector(".navi-menu-screeners-in-desktop > .navi-menu-drop-down-icon")).click();
		TimeUnit.SECONDS.sleep(2);

		driver.findElement(By.linkText("�ۭq���")).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(By.cssSelector("#user1 .group-action-import-all")).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(By.linkText("�}�l���")).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(By.id("result-content"));
		TimeUnit.SECONDS.sleep(2);
		{
			List<WebElement> elements = driver.findElements(By.cssSelector("#result-content tbody tr .r-td2"));

			List<WebElement> elementsrank = driver
					.findElements(By.cssSelector("#result-content tbody tr td:nth-child(15) div"));

			WebElement elementtbody = driver.findElement(By.cssSelector("#result-content #r-main"));

			content.append("<table>");
			content.append(elementtbody.getAttribute("innerHTML"));
			content.append("</table>");
//			int count = elements.size();

//			content.append("No");
//			content.append("  ");
//			content.append("Name");
//			content.append(" ");
//			content.append("��{%");
//			content.append("  ");
//			content.append("\n");

//			for (int i = 0; i < count; i++) {
//
////				String cat = elements.get(i).getAttribute("innerHTML");
////				int index = cat.lastIndexOf("</a>");
////				String output = cat.substring(index + 4);
//
//				content.append(elements.get(i).getText());
//				content.append("  ");
////				content.append(output);
////				content.append("  ");
//				content.append(elementsrank.get(i).getAttribute("innerHTML"));
//				content.append("  ");
//				content.append("\n");
//
//			}

//			elements.stream().forEach(c -> {
//
//				String cat = c.getAttribute("innerHTML");
//
//				int index = cat.lastIndexOf("</a>");
//
//				String output = cat.substring(index + 4);
//
//				content.append(c.getText());
//				content.append("  ");
//				content.append(output);
//				content.append("\n");
//				System.out.println(c.getAttribute("innerHTML"));
//				System.out.println(c.getAttribute("href"));
//			});
//
//			elementsrank.stream().forEach(c -> {
//				content.append(c.getAttribute("innerHTML"));
//				content.append("\n");
//				System.out.println(c.getAttribute("innerHTML"));
//
//			});

		}

		driver.close();

		return content.toString();
	}
}
