package com.alen.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormatUtil {

	/**
	 * �榡�Ʈɶ�
	 * 
	 * @param date
	 * @param format
	 * @return String
	 */
	public static String format(Date date, String format) {
		SimpleDateFormat sdFormat = new SimpleDateFormat(format);
		return sdFormat.format(date);
	}
	
	
	public static Date formatToDate(String date, String format) throws ParseException {
		SimpleDateFormat sdFormat = new SimpleDateFormat(format);
		return sdFormat.parse(date);
	}

}
