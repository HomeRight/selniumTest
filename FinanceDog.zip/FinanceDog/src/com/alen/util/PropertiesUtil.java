package com.alen.util;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 * �]�m�P���oPropertise�@�Τ���
 * 
 * @author Luke-Hong
 * @since 2019/09/18
 *
 */
public class PropertiesUtil {

	private static Properties properties;

	/**
	 * ��l�ưѼƳ]�w
	 * 
	 * @param propertiesFile �ɮצW��
	 * @throws Exception
	 */
	public static void init(String propertiesFile) throws Exception {
		try {
			// Ū���~��Config
			properties = new Properties();
			String filePath = System.getProperty("user.dir") + "/" + propertiesFile;
			InputStream in = new BufferedInputStream(new FileInputStream(filePath));
			properties.load(in);
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * �ھ�Key�Ȩ��o�]�w��
	 * 
	 * @param prepKey �]�wKey
	 * @return �]�w��
	 */
	public static String getValue(String prepKey) {
		return properties.getProperty(prepKey);
	}

}
